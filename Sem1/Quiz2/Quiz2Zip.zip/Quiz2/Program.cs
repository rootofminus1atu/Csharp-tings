﻿namespace Quiz2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter customer name: ");
            string name = Console.ReadLine();

            Console.Write("Enter number of lawns: ");
            int lawnsNumber = int.Parse(Console.ReadLine());

            Console.Write("Enter size of lawns in square meters: ");
            double lawnsSize = double.Parse(Console.ReadLine());

            Console.Write("Enter cost per 50 liters of fertilizer: ");
            double fertCost = double.Parse(Console.ReadLine());

            Console.Write("Enter cost per bag of seed: ");
            double seedCost = double.Parse(Console.ReadLine());

            Console.OutputEncoding = System.Text.Encoding.UTF8;

            double fertCostTotal;
            double fertCostTotalVat;
            double seedCostTotal;
            double seedCostTotalVat;
            double allLawnCost;
            double laborCostTotal;
            double laborCostTotalVat;
            double allLaborCost;
            double jobCost;

            double discount;
            double discountAmount;
            string star = "";

            double fertLiters;
            double fertGallons;

            const double LAWN_REQ = 25;   // 25 square meters

            const double LABOR_COST = 25;

            const double PRODUCTS_VAT = 0.2;
            const double LABOR_VAT = 0.15;

            const double FERT_VOLUME = 50;
            const double L_TO_G = 0.2199;
            const double EUR_TO_STER = 0.85;

            double amountOfReqs = ((lawnsNumber * lawnsSize) / LAWN_REQ);  // amount of 25sqm areas



            // 2nd big display row

            fertCostTotal = amountOfReqs * fertCost;
            fertCostTotalVat = fertCostTotal * PRODUCTS_VAT; 

            seedCostTotal = amountOfReqs * 2 * seedCost;
            seedCostTotalVat = seedCostTotal * PRODUCTS_VAT;

            allLawnCost = fertCostTotal + fertCostTotalVat + seedCostTotal + seedCostTotalVat;



            // 3rd big display row

            laborCostTotal = amountOfReqs * 5 * LABOR_COST;
            laborCostTotalVat = laborCostTotal * LABOR_VAT;

            allLaborCost = laborCostTotal + laborCostTotalVat;



            // 4th big display row

            jobCost = allLawnCost + allLaborCost;

            if (jobCost < 1000)
                discount = 0;

            else if (jobCost > 5000)
                discount = 0.08;

            else
                discount = 0.05;

            discountAmount = jobCost * discount;

            if (discountAmount > 100)
                star += "*";



            // 5th big display row

            fertLiters = amountOfReqs * FERT_VOLUME;
            fertGallons = fertLiters * L_TO_G;



            const int k = -35;  // the indent, so that everything would be aligned

            Console.WriteLine("\n\nMurphy Bros Garden Centre");
            Console.WriteLine("       Job Quote");

            Console.WriteLine(StringMult("=", 25));  // a function that writes 25 strings

            Console.WriteLine($"{"Customer name",k}: {name}\n");
            Console.WriteLine($"{"Total number of lawns", k}: {lawnsNumber}");
            Console.WriteLine($"{"Cost of 50 liters of fertilizer", k}: {fertCost:c2}");
            Console.WriteLine($"{"Cost of oe 25kg bag of seeds",k}: {seedCost:c2}");

            Console.WriteLine(StringMult("-", 60));

            Console.WriteLine($"{"Cost of fertilizer",k}: {fertCostTotal:c2}");
            Console.WriteLine($"{"Fertilizer VAT",k}: {fertCostTotalVat:c2}");
            Console.WriteLine($"{"Cost of seed",k}: {seedCostTotal:c2}");
            Console.WriteLine($"{"Seed VAT",k}: {seedCostTotalVat:c2}");
            Console.WriteLine($"{"Total cost of lawn",k}: {allLawnCost :c2}");

            Console.WriteLine(StringMult("-", 60));

            Console.WriteLine($"{"Labor hourly cost",k}: {LABOR_COST:c2}");
            Console.WriteLine($"{"Labor cost",k}: {laborCostTotal:c2}");
            Console.WriteLine($"{"Labor VAT",k}: {laborCostTotalVat:c2}");
            Console.WriteLine($"{"Total labor cost",k}: {allLaborCost:c2}");

            Console.WriteLine(StringMult("-", 60));

            Console.WriteLine($"{"Total cost of job",k}: {jobCost:c2}");
            Console.WriteLine($"\n{"Discount rate",k}: {discount:p2}");
            Console.WriteLine($"{"Discount amount",k}: {discountAmount:c2}{star}\n");
            Console.WriteLine($"{"Nett Cost",k}: {jobCost - discountAmount:c2}");

            Console.WriteLine(StringMult("-", 60));

            Console.WriteLine($"{"UK Figures",k}");
            Console.WriteLine($"{"Total number of gallons",k}: {fertGallons}");

            Console.WriteLine($"{"Net Str Equivalent",k}: {jobCost * EUR_TO_STER:.##} sterling");
        }

        public static string StringMult(string thing, int n)
        {
            string line = "";

            for (int i = 0; i < n; i++)
                line += thing;

            return line;
        }

    }
}