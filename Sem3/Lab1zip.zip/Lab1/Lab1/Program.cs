﻿namespace Lab1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // lab 1 exercises
        }
    }
}