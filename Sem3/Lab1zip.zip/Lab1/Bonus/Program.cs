﻿namespace Bonus
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Mark mark = new Mark(95, HO.H);

            Console.WriteLine(mark.ToString());

        }
    }
}